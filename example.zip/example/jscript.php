<?php
error_reporting(0);
include("connection.php");


if(isset($_REQUEST['submit']))
{
	if(isset($_REQUEST['eid']))
	{
		$f=$_REQUEST['eid'];
		$f1=$_REQUEST['name'];
		$f2=$_REQUEST['lname'];
		$f3=$_REQUEST['email'];
		$f4=$_REQUEST['pass'];
		$f5=$_REQUEST['gender'];
		$f6=$_REQUEST['des'];
		$f7=$_REQUEST['add'];

		$upd=mysql_query("update javascript set name='$f1',lname='$f2',email='$f3',password='$f4',gender='$f5',designation='$f6',address='$f7' where id='$f'")or die(mysql_error());
		header("location:display.php");
	}

	else
	{
	$f1=$_REQUEST['name'];
	$f2=$_REQUEST['lname'];
	$f3=$_REQUEST['email'];
	$f4=$_REQUEST['pass'];
	$f5=$_REQUEST['gender'];
	$f6=$_REQUEST['des'];
	$f7=$_REQUEST['add'];
	
	
	
	
	$int=mysql_query("insert into javascript values('','$f1','$f2','$f3','$f4','$f5','$f6','$f7')");
	header("location:display.php");
	}

	

}




?>


<?php
error_reporting(0);
include("connection.php");
session_start();
$f1=$_SESSION['email'];
$sel1=mysql_query("select * from javascript where id='$f1'") or die(mysql_error());
$row1=mysql_fetch_array($sel1);
?>

<html>
<head>
<title> Practical </title>
<script type="text/javascript" language="javascript">
		function abc()
		{
			a=document.forms["frm"]["name"].value;
			b=document.forms["frm"]["lname"].value;
			c=document.forms["frm"]["email"].value;
			d=document.forms["frm"]["pass"].value;
			e=document.forms["frm"]["gender"].value;
			f=document.forms["frm"]["des"].value;
			g=document.forms["frm"]["add"].value;
			
			
			rchar=/[a-zA-Z]/;
			em=/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z0-9]{2,4}$/;
			mobile=/^[789]\d{9}$/;
			pa=/[a-zA-Z0-9@.-_]/;
			ad=/[a-zA-Z,.:-]/;
			
			
			if(a=="" || a=="null")
			{
				alert("enter first name");
				return false;
			}
			if(rchar.exec(a)==null)
			{
				alert("enter only character");
				return false;
			}
			
			if(b=="" || b=="null")
			{
				alert("enter last name");
				return false;
			}
			if(rchar.exec(b)==null)
			{
				alert("write  only alphabet numeric @._- ");
				return false;
			}
			
			
			if(c=="" || c=="null")
			{
				alert("enter email");
				return false;
			}
			if(em.exec(c)==null)
			{
				alert("enter proper format");
				return false;
				
			}
			if(d=="" || d==null)
			{
				alert("enter password");
				return false;
				
			}
			if(pa.exec(d)==null)
			{
				alert("enter  password");
				return false;
				
				
			}
			if(e=="" || e==null)
			{
				alert("select gender");
				return false;
			}
			if(rchar.exec(e)==null)
			{
				alert("select gender");
				return false;
			}
			
			
			if(f=="" || f==null)
			{
				alert("select designation");
				return false;
			}
			if(rchar.exec(f)==null)
			{
				alert("select designation");
				return false;
			}
			
			
			if(g=="" || g==null)
			{
				alert("enter address");
				return false;
			}
			if(ad.exec(g)==null)
			{
				alert("enter proper address");
				return false;
			}
		}
</script>
</head>
<body>
<form method="post" name="frm" onsubmit="return abc()">
<table align="center">

<?php
error_reporting(0);
include("connection.php");

if(isset($_REQUEST['eid']))
{
		$f=$_REQUEST['eid'];


		$sel=mysql_Query("select * from javascript where id='$f'") or die (mysql_error());
		$row1=mysql_fetch_array($sel);
}


?>


<tr>
<td>Name</td>
<td><input type="text" name="name"  value="<?php echo $row1['1'];?>"/></td>
</tr>
<tr>
<td>Lname</td>
<td><input type="Lname" name="lname"  value="<?php echo $row1['2'];?>"/></td>
</tr>
<tr>
<td>Email</td>
<td><input type="Email" name="email" value="<?php echo $row1['3'];?>"/></td>
</tr>
<tr>
</tr>
<tr>
<td>Password</td>
<td><input type="Password" name="pass" value="<?php echo $row1['4'];?>"/></td>
</tr>
<tr>
<td>Gender</td>
<td>
<input type="radio" name="gender" value="Male" <?php if($row1['gender']=="Male") {echo "checked"; }?>/>Male
<input type="radio" name="gender" value="Female" <?php if($row1['gender']=="Female"){echo "checked"; }?> />Female
</td>
</tr>
<tr>
<td>Designation</td>
<td>
<select name="des">
<option value="<?php echo $row1['designation'];?>" <?php echo $row1['designation'];?></option>
<option> All </option>
<option>PHP</option>
<option>Asp.net</option>
<option>Vb.net</option>
<option>JAVA</option>
</select>
</td>
</tr>
<tr>
<td>Address</td>
<td><textarea name="add" row="10" cols="10" value="<?php echo $row1['address'];?>"></textarea>
</td>
</tr>


<tr>
<td></td>
<td><input type="submit" name="submit" value="submit" class="btn btn-warning"/></td>
</tr>

</table>
</form>
</body>
</html>