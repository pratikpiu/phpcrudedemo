<?php
include("connection.php");


$sel1=mysql_query("select * from javascript");

if(isset($_REQUEST['did']))
	{
		$sel=$_REQUEST['did'];

		$del=mysql_query("delete from javascript  where id='$sel'");
		header("location:display.php");


	}
?>



<html>
<head></head>
<body>
<table align="center" border="1">

<tr>
<th>Id</th>
<th>Name</th>
<th>Lname</th>
<th>Email</th>
<th>Password</th>
<th>Gender</th>
<th>Designation</th>
<th>Addresss</th>
<th>Edit</th>
<th>Delete</th>
</tr>


<?php
while($row=mysql_fetch_array($sel1))

{

?>

<tr>
	<td><?php echo $row['id'];?></td>
	<td><?php echo $row['name'];?></td>
	<td><?php echo $row['lname'];?></td>
	<td><?php echo $row['email'];?></td>
	<td><?php echo $row['password'];?></td>
	<td><?php echo $row['gender'];?></td>
	<td><?php echo $row['designation'];?></td>
	<td><?php echo $row['address'];?></td>
	<td><a href="jscript.php?eid=<?php echo $row['id'];?>">Edit</a></td>
	<td><a href="display.php?did=<?php echo $row['id'];?>">Delete</a></td>
</tr>


<?php
  
}

?>


</table>
</body>
</html>