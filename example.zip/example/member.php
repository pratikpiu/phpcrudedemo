<?php
session_start();
if(isset($_SESSION["sess_email"]))
{
	header("location:home.php");
}
else
{
	
?>


<html>
<head>  </head>
<body>
<center><h3> WELCOME </h3></center>

<p>Jaydip Patel
B-403 • Samrat App. • Shilpapark Soc. • Opp. Rangabdhut Soc. • Matavadi • Surat • 395006
CELL (+91) 9033639605 • E-MAIL 605jdpatel@gmail.com
 
OBJECTIVE
I am keen to contribute to the success and growth of the organization by undertaking the challenging assignments and delivering timely results by applying best of my knowledge and skills.
 
EDUCATION

Qualification	College	Board	Year	Aggregate
Bachelors in  I.T Engineering	Sancalchand Patel College Of Engineering, Visnager	GTU	2015	7.00 CGPA
Diploma in I.T	Bhagvan Mahavir Polytechnic College, Surat	GTU	2012	6.06 CGPA
SSC	A.V. Patel High School, Surat	GSEB	2009	70.15%
 
COMPUTER SKILLS

	Web Technologies:
CodeIgnitor, MVC, CSS, JavaScript, Ajax, Web services.	

	Programming Languages:	
	C, C++, PHP, VB.Net

Web Server:						 DBMS/RDBMS:
Apache HTTP Server, WAMP, XAMPP		            MYSQL, MS Access

	Operating System:
	MS_DOS, Windows-XP, Windows-7, 8, Linux.

Tools:
	Microsoft Office, Adobe Dreamweaver, Photoshop 7.0, Visual studio 2008.
 
ACADEMIC PROJECTS
	
Diploma I.T (Final year) Project Training (2011-2012) 

Title: 		Youth India Social Group. 
Company Name: 	Cygnus Soft Tech. 
Back-end:		SQL SERVER 2005 
Front-end:		Visual studio .Net 2008 	
Duration: 		1 year 
Position: 		Developer 
Application: 		WINDOWS BASE APPLICATION 
Responsibilities: 	1. Develop a code for application
2. Database manipulation
	
B.E I.T (Final Year) Project Training (2014-2015) 

Title:			 Mob-Textile ERP System 
Company Name: 	 Aurosoft
Back-end: 		 My SQL 5.5.8 
Front-end: 		 PHP 
Duration: 		 1 year 
Position: 		 Developer 
Application:		 WEB APPLICATION 
Responsibilities: 	 1. Proper Analysis and require Information Gathering. 
 2. Maintain Database. 
 					 3. Develop a code for application. 
TOPS TECHNOLOGIES Project Training (2015) 

Title:			 Health Information Technology
Back-end: 		 My SQL 
Front-end: 		 PHP
Duration: 		 4 month 
Position: 		 Developer 
Application:		 WEB APPLICATION 
Responsibilities: 	 1. Developer 
 2. Maintain Database. 
 3. Designing.
 
HOBBIES	
Arts
Listening to music, cinema, Writing. 

Sports
Football, Basketball, Cricket, Cycling, Tennis. 

Leisure
Reading newspapers, Reading different motivational books, Social Networking, Travelling to different places. 
 
ACHIVEMENT	
•	In 2014 had attended the workshop on ORACLE DATABASE ADMINISTRATOR.
•	In marketing filled one hundred & fifty member managing award achieved. 
•	Participated in youth festival 2014 skit third position in GTU. 
•	Achieved certificate of ALUMANI ASSOCIATION OF NCC CADETS [AAN]. 
•	In E-lite Pvt. Ltd. Company achieved multi income award.

REFERENCE AVAILABLE UPON REQUEST

</p>
<tr>
<td></td>
<td><center><h3><a href="logout.php">logout</h3></center></a></td>
</tr>
</body>

</html>

<?php

}

?>