<?php
error_reporting(0);
include("connection.php");



if(isset($_REQUEST['submit']))
{
	session_start();
	$f1=$_REQUEST['email'];
	$f2=$_REQUEST['pass'];
	
	
	$sel=mysql_query("select * from javascript where email='$f1' and password='$f2'")or die(mysql_error());
	$numrow=mysql_num_rows($sel);
	
	if($numrow!==0)
	{
		while($row=mysql_fetch_assoc($sel))
		{	
		$dbemail=$row['email'];
		$dbpassword=$row['pass'];
		}
	if($email==$dbemail && $pass=$dbpassword)
	{
		session_start();
		$_SESSION['sess_email']=$email;
		header("location:member.php");
	}
		
	else
	{
		echo "Invalid email and password";
	}
 }
}

?>


<?php
if(isset($_REQUEST['signin']))
{
	header("location:jscript.php");
}

?>
<html>
<head>
<title></title>
<script method="text/javascript" language="javascript">
	function abc()
	{
		a=document.forms["frm"]["email"].value;
		b=document.forms["frm"]["pass"].value;
		
		
		em=/^[a-zA-Z0-9.-_]+@[a-zA_Z0-9.-]+\.[a-zA-Z0-9]{2,4}$/;
		pa=/^[a-zA-Z0-9.-_@];
		
		
		
		
		if(a=="" || a==null)
		{
			alert("enter email address");
			return false;
		}
		if(em.exec(a)==null)
		{
			alert("enter proper address");
			return false;
		}
		
		if(b=="" || b==null)
		{
			alert("enter password");
			return false;
		}
		if(pa.exec(b)==null)
		{
			alert("enter valid password");
			return false();
		}
	}
</script>
</head>
<body>
<p><a href="home.php">home</a> || <a href="jscript.php">jscript</a>
<center><h3>LOGIN FORM</h3></center>
<form method="post" name="frm" onsubmit="return abc()">
<table align="center" border="2">
<tr>
<td>Email</td>
<td><input type="text" name="email" value=""/>
</td>
</tr>
<tr>
<td>Password</td>
<td><input type="password" name="pass" value=""/>
</td>
</tr>

<tr>
<td></td>
<td><input type="submit" name="submit" value="Login" class="btn btn-warning"/>
<input type="submit" name="signin" value="signin"/></td>

</tr>
</table>
<table>
<tr>
<center><p>you have't account? signin</p></center>

</tr>

</table>
</form>
</body>
</html>